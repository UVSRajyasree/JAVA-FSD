package project;

import java.util.*;

public class Queue1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //String
		Queue<String> locationsQueue = new LinkedList<>();
		locationsQueue.add("City");
	    locationsQueue.add("Hyderabad");
	    locationsQueue.add("Andhra Pradesh");
	    locationsQueue.add("Chennai");
        locationsQueue.add("Bangalore");
		System.out.println("Queue is : " + locationsQueue);
	    System.out.println("Head of Queue : " + locationsQueue.peek());
	    locationsQueue.poll();
	    System.out.println("After removing Head of Queue : " + locationsQueue);
	    System.out.println("Size of Queue : " + locationsQueue.size());
	    //Integer
	    Queue<Integer> a = new LinkedList<>();
	    a.add(10);
	    a.add(100);
	    a.add(1000);
	    a.add(10000);
	    a.add(100000);
	    System.out.println("Head Of Queue is: " + a);
	    a.poll();
	    System.out.println("After removing Head Of Queue is: " + a);
	    System.out.println("Size Of Queue is: " + a.size());
	}

}
