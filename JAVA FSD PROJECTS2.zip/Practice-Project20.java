package project;

import java.util.Arrays;

class ArrayRotate{
public void rotate(int[] n, int a) {
	if(a > n.length) 
			a=a%n.length;
	int[] result = new int[n.length];
	for(int i=0; i < a; i++){
			result[i] = n[n.length-a+i];
	}
	int j=0;
	for(int i=a; i<n.length; i++){
			result[i] = n[j];
            j++;
	}
	System.arraycopy( result, 0, n, 0, n.length );
    }
}
public class ArrayRotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayRotate r = new ArrayRotate();
		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
		r.rotate(arr, 5); 
		for(int i=0;i<arr.length;i++){
				System.out.print(arr[i]+" ");
		}
   
	}
}
