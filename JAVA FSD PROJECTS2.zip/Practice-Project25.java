package project;

public class CircularLinkedList {
	static class Node 	{ 
		int data; 
    		Node next; 
            	Node(int d) 
    		{ 
        			data = d; 
        			next = null; 
    		} 
}
Node head; 
CircularLinkedList()   { 
head = null; 
} 
//Method To Insert A New Element Into The Sorted Circular Linked List
	void sortedInsert(Node new_node) { 
    		Node current = head; 
    //If The List Is Empty, Insert The New Node And Make It Circular
    if (current == null) { 
        			new_node.next = new_node; 
        			head = new_node; 
		} 
    else if (current.data >= new_node.data) {
    	//Traverse The List To Find The Correct Position To Insert The New Node
    while (current.next != head) 
            			current = current.next; 
		 	current.next = new_node; 
        			new_node.next = head; 
        			head = new_node; 
    		} 
    		else{
    			//Insert The New Node
    while (current.next != head && current.next.data < new_node.data) 
            			current = current.next; 
			new_node.next = current.next; 
        			current.next = new_node; 
    		} 
}
	//Method To Display The Sorted Circular Linked List
void printList() { 
    		if (head != null) { 
        			Node temp = head; 
        			do{ 
            			System.out.print(temp.data + " "); 
            			temp = temp.next; 
        			}  while (temp != head); 
    		} 
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //Creating A Sorted  Circular Linked List
		CircularLinkedList list = new CircularLinkedList();
		//Inserting Elements Into The Sorted Circular Linked List
		int arr[] = new int[] {12, 34, 78, 56, 200, 11, 100, 90}; 
		//Displaying The Sorted Linked List
		Node temp = null; 
		for (int i = 0; i < 8; i++) { 
   			temp = new Node(arr[i]); 
    			list.sortedInsert(temp); 
		} 
list.printList(); 

	}

}
