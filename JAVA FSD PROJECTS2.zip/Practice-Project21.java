package project;

class FourthSmallest 
{ 
int fourthSmallest(int arr[], int a, int b, int c) 
    	{ 
             		if (c > 0 && c <= b - a + 1) 
        		{ 
            			int pos = randomPartition(arr, a, b); 
            			if (pos-a == c-1) 
                			return arr[pos]; 
            			if (pos-a > c-1) 
                			return fourthSmallest(arr, a, pos-1, c); 
            			return fourthSmallest(arr, pos+1, b, a-pos+c-1); 
        		} 
        return Integer.MAX_VALUE; 
    } 
    void swap(int arr[], int i, int j) 
    { 
        int temp = arr[i]; 
        arr[i] = arr[j]; 
        arr[j] = temp; 
    } 
    int partition(int arr[], int a, int b) 
    { 
        int x = arr[b], i = a; 
        for (int j = a; j <= b - 1; j++) 
        { 
            if (arr[j] <= x) 
            { 
                swap(arr, i, j); 
                i++; 
            } 
        } 
        swap(arr, i, b); 
        return i; 
    } 
    int randomPartition(int arr[], int a, int b) 
    { 
        int n = b-a+1; 
        int pivot = (int)(Math.random()) * (n-1); 
        swap(arr, a + pivot, b); 
        return partition(arr, a, b); 
    } 
}  

public class OrderStatistics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FourthSmallest om = new FourthSmallest(); 
        int arr[] = {1, 3, 2, 4, 6, 5, 7, 9, 8, 10}; 
        int n = arr.length,a = 4; 
        System.out.println("Fourth smallest element is "+ om.fourthSmallest(arr, 0, n-1, a)); 

	}

}
