package project;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				//Implicit Conversion
				System.out.println("Implicit Type Casting");
				//int to float
				int s=100;
				float t=s;
				System.out.println("Value of s: "+t);
				
				//char
				char a='A';
				System.out.println("Value of a: "+a);
				
				//char to int
				int b=a;
				System.out.println("Value of b: "+b);
				
				//char to float
				float c=a;
				System.out.println("Value of c: "+c);
				
				//char to long
				long d=a;
				System.out.println("Value of d: "+d);
				
				//char to double
				double e=a;
				System.out.println("Value of e: "+e);
				
						
				System.out.println("\n");
				
				System.out.println("Explicit Type Casting");
				//Explicit Conversion
				
				//float to int
			    float p = (float)100.0;
				int r = (int)p; 
				System.out.println("Value of p: "+p);
				System.out.println("Value of r: "+r);
				
				//double to int
				double x=45.5;
				int y=(int)x;
				System.out.println("Value of x: "+x);
				System.out.println("Value of y: "+y);
				
	}

}
