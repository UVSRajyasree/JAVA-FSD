package project;

//Parameterized Constructor
class Employee1{
	int id;
	String name;
	float salary;
	
	Employee1(int i, String n, float s){
		id=i;
		name=n;
		salary=s;	
	}
	
void Details() {
	System.out.println(id+" "+name+" "+salary);
	}
}
public class ParameterizedConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee1 e1=new Employee1(1, "Ram", 25000);
		Employee1 e2=new Employee1(2, "Lakshman", 25000);
	    e1.Details();
	    e2.Details();
	   
	}

}
