package project;

//Default Constructor
class Employee{
	int id;
	String name;
	float salary;
	
void Details() {
	System.out.println(id+" "+name+" "+salary);
	}
}


public class DefaultConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Employee e=new Employee();
    e.Details();
	}

}
