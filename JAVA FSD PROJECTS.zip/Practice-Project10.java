package project;

import java.util.regex.*;

public class RegularExpressions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//First Way
		Pattern pattern = Pattern.compile(".s");
		
		Matcher matcher = pattern.matcher("as");
		boolean Result_1=matcher.matches();
		System.out.println(Result_1);
		
		//Second Way
		boolean Result_2=Pattern.compile(".s").matcher("as").matches();
		System.out.println(Result_2);
		
		//Third Way
		boolean Result=Pattern.matches(".s","as");
		System.out.println("Result");
		
		
		//Checking SubStrings
		String pattern1 = "[A-z]+";
		String pattern2 = "[1-100]+";
		String check = "Regular Expressions";
		Pattern p = Pattern.compile(pattern1);
		Matcher c = p.matcher(check);
		Pattern p1 = Pattern.compile(pattern2);
		Matcher c1 = p1.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start(), c.end()) );
	}

}
