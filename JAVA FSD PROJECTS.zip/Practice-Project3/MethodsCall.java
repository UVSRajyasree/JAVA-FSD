package project;

//Call By Value
public class MethodsCall {
	int p=98;

	int adding(int p) {
		p =p+100;
		return(p);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodsCall m = new MethodsCall();
		System.out.println("Before Adding the Value is: "+m.p);
		m.adding(100);
		System.out.println("After Adding the Value is: "+m.p);
	}

}
