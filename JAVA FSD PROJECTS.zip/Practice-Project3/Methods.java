package project;

//Method
public class Methods {
	public int addnumbers(int a,int b) {
		int c=a+b;
		return c;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Methods b=new Methods();
		int ans= b.addnumbers(90,10);
		System.out.println("Addition is :"+ans);

	}

}


//Method Overloading
class overloadMethod {
	
public void area(int s,int t)
    {
         System.out.println("Area of Square : "+(0.5*s*t));
    }
    public void area(int r) 
    {
         System.out.println("Area of Circle : "+(3.14*r*r));
    }

    public static void main(String args[])
   {

overloadMethod ob=new overloadMethod();
       ob.area(10,12);
       ob.area(5);  
   }
}

