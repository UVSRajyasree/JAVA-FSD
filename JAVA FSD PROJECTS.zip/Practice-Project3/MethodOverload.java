package project;

//Method Overloading
public class MethodOverload {
	public void multiply(int s,int t)
    {
         System.out.println("Multiplication is : " + (s*t));
    }
    public void multiply(int r,int t,int p) 
    {
         System.out.println("Multiplication is : " + (r*t*p));
    }
	public void multiply(int r, float t)
	{
		System.out.println("Multiplication is :" + (r*t));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverload mo=new MethodOverload();
	       mo.multiply(10,10);
	       mo.multiply(10,10,10);
	       mo.multiply(10,10.0f);
	}

}
