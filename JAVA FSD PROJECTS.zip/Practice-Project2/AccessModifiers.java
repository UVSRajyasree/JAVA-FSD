package project;

//1. Default Access Modifier
class defaultAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("This is Default Access Specifier"); 
     } 
} 

public class AccessModifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Dafault Access Specifier");
		defaultAccessSpecifier obj = new defaultAccessSpecifier(); 		  
        obj.display(); 
        
      

	}

}




