package projects;

import project.*;

//Public Access Modifier
public class AccessModifier3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifiers3 obj = new AccessModifiers3(); 
        obj.display();  

	}

}
