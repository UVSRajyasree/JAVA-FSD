package project;

//2. Private Access Modifier
class privateaccessspecifier 
{ 
   private void display() 
    { 
        System.out.println("This is Private Access Modifier"); 
    } 
} 

public class AccessModifiers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//private
				System.out.println("Private Access Specifier");
				privateaccessspecifier  obj = new privateaccessspecifier(); 
		        //trying to access private method of another class 
		        //obj.display();

	}

}
