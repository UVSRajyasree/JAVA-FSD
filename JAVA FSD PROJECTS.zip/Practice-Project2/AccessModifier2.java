package projects;

import project.*;

//Protected Access Specifier
public class AccessModifier2 extends AccessModifiers2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifier2 obj = new AccessModifier2 ();    
        obj.display();
        
	}

}
