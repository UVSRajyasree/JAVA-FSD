package project;

//4. Public Access Modifier
public class AccessModifiers3 {
	public void display() 
    { 
        System.out.println("This is Public Access Specifier"); 
    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
	}

}
