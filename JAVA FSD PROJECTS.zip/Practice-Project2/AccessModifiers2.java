package project;

//3. Protected Access Modifier
public class AccessModifiers2 {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    AccessModifiers2 obj= new AccessModifiers2();
    obj.display();
	
	}

}
