package project;

public class Strings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		       //Methods of Strings
				System.out.println("String Methods");
				
				String sl=new String("Hello Java");
				System.out.println("Length Of String is:" + sl.length());

				//substring
				String sub=new String("Welcome");
				System.out.println("Sub String is : " + sub.substring(2));

				//String Comparison
				String s1="Hello";
				String s2="Hi";
				System.out.println("Comparison of Two Strings is: " + s1.compareTo(s2));

				//IsEmpty
				String s4="";
				System.out.println("Empty String is :" + s4.isEmpty());

				//toLowerCase
				String s5="Hello";
				System.out.println("Convert to Lower Case is : " + s1.toLowerCase());
				
				//replace
				String s6="Heldo";
				String replace=s2.replace('d', 'l');
				System.out.println("String Replace is :" + replace);

				//equals
				String x="Welcome to Java";
				String y="WeLcOmE tO JaVa";
				System.out.println("Are Two Strings Equal :" + x.equals(y));
		 
				System.out.println("\n");
				System.out.println("This is StringBuffer");
				//Creating StringBuffer and append method
				StringBuffer s=new StringBuffer("Welcome to Java");
				s.append("Enjoy your learning");
				System.out.println(s);

				//Insert method
				s.insert(0, 'a');
				System.out.println(s);

				//Replace method
				StringBuffer sb=new StringBuffer("Hello");
				sb.replace(0, 1, "hEl");
				System.out.println(sb);

				//Delete method
				sb.delete(0, 1);
				System.out.println(sb);
				
				//StringBuilder
				System.out.println("\n");
				System.out.println("This is StringBuilder");
				StringBuilder sb1=new StringBuilder("Happy");
				sb1.append("Learning");
				System.out.println(sb1);
                
				//Delete
				System.out.println(sb1.delete(0, 1));
 
				//Insert
				System.out.println(sb1.insert(1, "Welcome to"));
                
				//Reverse
				System.out.println(sb1.reverse());
						
				//Conversion	
				System.out.println("\n");
				System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
				
				String str = "Hello"; 
		        
		        // Conversion from String object to StringBuffer 
		        StringBuffer sbr = new StringBuffer(str); 
		        sbr.reverse(); 
		        System.out.println("String to StringBuffer");
		        System.out.println(sbr); 
		          
		        // Conversion from String object to StringBuilder 
		        StringBuilder sba = new StringBuilder(str); 
		        sba.append("World"); 
		        System.out.println("String to StringBuilder");
		        System.out.println(sba);              

	}

}
