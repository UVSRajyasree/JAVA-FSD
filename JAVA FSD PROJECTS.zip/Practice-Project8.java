package project;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Single Dimensional Array
		int a[]= {100,200,300,400,500};
		
		for(int i=0;i<5;i++) {
			if(a[i]%100==0) {
				System.out.println("The Numbers are Divisible By 100 is : "+a[i]);
			}
			else {	
			
		System.out.println("Elements of array a: "+a[i]);
			}
		
		}


		//Multi Dimensional Array
		int[][] b = {
		            {10,20,30,40,50},
		            {60,70,80,90,100}};
		
		      System.out.println("\nFirst Row Second Elemment" + b[0][1]);
		      
		      System.out.println("\nSecond Row First Element" + b[1][0]);
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      
		      System.out.println("\nLength of row 2: " + b[1].length);

	}

}
