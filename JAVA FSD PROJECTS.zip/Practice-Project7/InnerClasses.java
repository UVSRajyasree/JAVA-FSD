package project;

public class InnerClasses {

	private int a=100; 
	 
	 class InnerClass{  
	  void Display(){
		  System.out.println("This is inner class :" + a);
		  }  
	 }  


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		InnerClasses c=new InnerClasses();
		InnerClasses.InnerClass in=c.new InnerClass();  
		in.Display();  

	}

}
