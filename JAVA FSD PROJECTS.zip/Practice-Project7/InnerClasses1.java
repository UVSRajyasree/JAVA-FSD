package project;

public class InnerClasses1 {
	private int b=1000;

	 void display(){  
		 class InnerClass1{  
			 void Number(){
				 System.out.println("The Value of b is:" + b);
			 }  
	  }  
	  
	  InnerClass1 d=new InnerClass1();  
	  d.Number();  
	 }  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		InnerClasses1  c=new InnerClasses1 ();  
		c.display();
	}

}
