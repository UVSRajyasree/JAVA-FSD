package project;

//Anonymous Class
abstract class AnonymousInnerClass {
	   public abstract void Change();
	}

public class InnerClasses2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnonymousInnerClass i = new AnonymousInnerClass() {

	         public void Change() {
	            System.out.println("This is Anonymous Inner Class");
	         }
	      };
	     
	      i.Change();

	}

}
