package jdbcprojects;

public class JDBCEnvironment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
