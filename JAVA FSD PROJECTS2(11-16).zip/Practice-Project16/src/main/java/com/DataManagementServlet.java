package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class DataManagementServlet
 */
public class DataManagementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/ecommerce";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "AaBb@12345678";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
//    public DataManagementServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");

        switch (action) {
            case "insert":
                insertData(request, response);
                break;
            case "update":
                updateData(request, response);
                break;
            case "delete":
                deleteData(request, response);
                break;
            default:
                response.getWriter().println("Invalid action");
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	private void insertData(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String name = request.getParameter("name");
            double price = Double.parseDouble(request.getParameter("price"));

            String insertDataSQL = "INSERT INTO eproduct (name, price) VALUES (?, ?)";

            try (PreparedStatement statement = connection.prepareStatement(insertDataSQL)) {
                statement.setString(1, name);
                statement.setDouble(2, price);

                int rowsAffected = statement.executeUpdate();

                PrintWriter out = response.getWriter();
                out.println("<html><head><title>Insert Data</title></head><body>");
                out.println("<h2>Insert Data</h2>");

                if (rowsAffected > 0) {
                    out.println("<p>Data inserted successfully!</p>");
                } else {
                    out.println("<p>Failed to insert data.</p>");
                }

                out.println("<a href=\"index.html\">Back to Home</a>");
                out.println("</body></html>");

            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().println("Error executing SQL query: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error establishing database connection: " + e.getMessage());
        }
	}
	private void updateData(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
	        int id = Integer.parseInt(request.getParameter("id"));
	        String newName = request.getParameter("newName");
	        double newPrice = Double.parseDouble(request.getParameter("newPrice"));

	        String updateDataSQL = "UPDATE eproduct SET name=?, price=? WHERE ID=?";

	        try (PreparedStatement statement = connection.prepareStatement(updateDataSQL)) {
	            statement.setString(1, newName);
	            statement.setDouble(2, newPrice);
	            statement.setInt(3, id);

	            int rowsAffected = statement.executeUpdate();

	            PrintWriter out = response.getWriter();
	            out.println("<html><head><title>Update Data</title></head><body>");
	            out.println("<h2>Update Data</h2>");

	            if (rowsAffected > 0) {
	                out.println("<p>Data updated successfully!</p>");
	            } else {
	                out.println("<p>Failed to update data. Record not found.</p>");
	            }

	            out.println("<a href=\"index.html\">Back to Home</a>");
	            out.println("</body></html>");

	        } catch (SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error executing SQL query: " + e.getMessage());
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        response.getWriter().println("Error establishing database connection: " + e.getMessage());
	    }
	}
	private void deleteData(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
	        int id = Integer.parseInt(request.getParameter("id"));

	        String deleteDataSQL = "DELETE FROM eproduct WHERE ID=?";

	        try (PreparedStatement statement = connection.prepareStatement(deleteDataSQL)) {
	            statement.setInt(1, id);

	            int rowsAffected = statement.executeUpdate();

	            PrintWriter out = response.getWriter();
	            out.println("<html><head><title>Delete Data</title></head><body>");
	            out.println("<h2>Delete Data</h2>");

	            if (rowsAffected > 0) {
	                out.println("<p>Data deleted successfully!</p>");
	            } else {
	                out.println("<p>Failed to delete data. Record not found.</p>");
	            }

	            out.println("<a href=\"index.html\">Back to Home</a>");
	            out.println("</body></html>");

	        } catch (SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error executing SQL query: " + e.getMessage());
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        response.getWriter().println("Error establishing database connection: " + e.getMessage());
	    }
	}
}
