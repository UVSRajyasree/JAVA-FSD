package com;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;

import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;




import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class DataServlet
 */

public class DataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/ecommerce";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "AaBb@12345678";
    //public DataServlet() {
     //   super();
        // TODO Auto-generated constructor stub
   // }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    static {
        // Load the MySQL JDBC driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");

        if ("List Data".equals(action)) {
            listData(response);
        } else if ("Add Data".equals(action)) {
            addData(response);
        }
   
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
//		String action = request.getParameter("action");
//
//        if ("List Data".equals(action)) {
//            listData(response);
//        } else if ("Add Data".equals(action)) {
//            addData(response);
//        }
    }
	private void listData(HttpServletResponse response) throws IOException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String sql = "SELECT * FROM eproduct";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    PrintWriter out = response.getWriter();
                    out.println("<html><head><title>Data List</title></head><body>");
                    out.println("<h2>Data List</h2>");
                    out.println("<table border=\"1\"><tr><th>ID</th><th>Name</th><th>Price</th><th>Date Added</th></tr>");

                    while (resultSet.next()) {
                        out.println("<tr>");
                        out.println("<td>" + resultSet.getLong("ID") + "</td>");
                        out.println("<td>" + resultSet.getString("name") + "</td>");
                        out.println("<td>" + resultSet.getDouble("price") + "</td>");
                        out.println("<td>" + resultSet.getTimestamp("date_added") + "</td>");
                        out.println("</tr>");
                    }

                    out.println("</table>");
                    out.println("<a href=\"index.html\">Back to Home</a>");
                    //out.println("<li><a href=\"html/listdata.html\">List Data</a></li>");
                    out.println("</body></html>");

                } catch (SQLException e) {
                    e.printStackTrace();
                    response.getWriter().println("Error retrieving data: " + e.getMessage());
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().println("Error executing SQL query: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error establishing database connection: " + e.getMessage());
        }
    }

    private void addData(HttpServletResponse response) throws IOException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String sql = "INSERT INTO eproduct (name, price, date_added) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Set values for the parameters
                statement.setString(1, "New Product");
                statement.setDouble(2, 49.99);
                statement.setTimestamp(3, new Timestamp(new Date().getTime()));

                int rowsAffected = statement.executeUpdate();

                PrintWriter out = response.getWriter();
                out.println("<html><head><title>Add Data</title></head><body>");
                out.println("<h2>Add Data</h2>");
                

                if (rowsAffected > 0) {
                    out.println("<p>Data added successfully!</p>");
                } else {
                    out.println("<p>Failed to add data.</p>");
                }

                out.println("<a href=\"index.html\">Back to Home</a>");
                out.println("</body></html>");
                //out.println("<li><a href=\"html/adddata.html\">Add Data</a></li>");

            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().println("Error executing SQL query: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error establishing database connection: " + e.getMessage());
        }
   
	}

}
