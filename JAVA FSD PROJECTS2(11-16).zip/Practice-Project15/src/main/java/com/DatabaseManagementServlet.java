package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class DatabaseManagementServlet
 */
public class DatabaseManagementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "AaBb@12345678";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
//    public DatabaseManagementServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");

        switch (action) {
            case "create":
                createDatabase(response);
                break;
            case "use":
                useDatabase(response);
                break;
            case "drop":
                dropDatabase(response);
                break;
            default:
                response.getWriter().println("Invalid action");
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	 private void createDatabase(HttpServletResponse response) throws IOException {
	        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
	            String dbName = "testdb";
	            String createDatabaseSQL = "CREATE DATABASE " + dbName;

	            try (java.sql.Statement statement = connection.createStatement()) {
	                statement.executeUpdate(createDatabaseSQL);

	                PrintWriter out = response.getWriter();
	                out.println("<html><head><title>Create Database</title></head><body>");
	                out.println("<h2>Database '" + dbName + "' created successfully</h2>");
	                out.println("<a href=\"index.html\">Back to Home</a>");
	                out.println("</body></html>");
	            } catch (SQLException e) {
	                e.printStackTrace();
	                response.getWriter().println("Error creating database: " + e.getMessage());
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error establishing database connection: " + e.getMessage());
	        }
	    }

	    private void useDatabase(HttpServletResponse response) throws IOException {
	        // Implement the logic to use a database
	        // This could involve opening a connection to an existing database and performing operations on it
	    	try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
	            String dbName = "testdb";
	            String useDatabaseSQL = "USE " + dbName;

	            try (java.sql.Statement statement = connection.createStatement()) {
	                statement.executeUpdate(useDatabaseSQL);

	                PrintWriter out = response.getWriter();
	                out.println("<html><head><title>Use Database</title></head><body>");
	                out.println("<h2>Using database '" + dbName + "'</h2>");
	                out.println("<a href=\"index.html\">Back to Home</a>");
	                out.println("</body></html>");
	            } catch (SQLException e) {
	                e.printStackTrace();
	                response.getWriter().println("Error using database: " + e.getMessage());
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error establishing database connection: " + e.getMessage());
	        }
	    
	    }

	    private void dropDatabase(HttpServletResponse response) throws IOException {
	        // Implement the logic to drop a database
	        // This could involve opening a connection and executing a "DROP DATABASE" SQL statement
	    	 try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
	             String dbName = "testdb";
	             String dropDatabaseSQL = "DROP DATABASE IF EXISTS " + dbName;

	             try (java.sql.Statement statement = connection.createStatement()) {
	                 statement.executeUpdate(dropDatabaseSQL);

	                 PrintWriter out = response.getWriter();
	                 out.println("<html><head><title>Drop Database</title></head><body>");
	                 out.println("<h2>Database '" + dbName + "' dropped successfully</h2>");
	                 out.println("<a href=\"index.html\">Back to Home</a>");
	                 out.println("</body></html>");
	             } catch (SQLException e) {
	                 e.printStackTrace();
	                 response.getWriter().println("Error dropping database: " + e.getMessage());
	             }
	         } catch (SQLException e) {
	             e.printStackTrace();
	             response.getWriter().println("Error establishing database connection: " + e.getMessage());
	         }
	     
	    }

}
