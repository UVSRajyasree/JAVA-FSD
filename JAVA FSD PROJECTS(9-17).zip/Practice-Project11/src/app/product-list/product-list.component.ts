import { Component } from '@angular/core';
import { Action } from 'rxjs/internal/scheduler/Action';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {

   toggleImage(): void{
    console.log("Image Toggle");
   }

   productprice: string="100";

   productname: string="1000";

}
