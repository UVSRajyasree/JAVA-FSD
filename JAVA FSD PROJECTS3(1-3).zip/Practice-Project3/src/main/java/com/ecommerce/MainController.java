package com.ecommerce;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ecommerce.EProduct;
import com.ecommerce.EProductDAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
@Controller
public class MainController {

	    @Autowired
	    private EProductDAO eProductDAO;

	    public void setEProductDAO(EProductDAO eProductDAO) {
	        this.eProductDAO = eProductDAO;
	    }

	    @RequestMapping("/listProducts")
	    public String listProducts(Model model) {
	        List<EProduct> products = eProductDAO.getAllProducts();
	        model.addAttribute("products", products);
	        return "listProducts";
	    }
}
