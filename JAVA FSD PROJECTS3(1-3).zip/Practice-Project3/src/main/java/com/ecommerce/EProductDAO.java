package com.ecommerce;

import com.ecommerce.EProduct;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;

public class EProductDAO {

	private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<EProduct> getAllProducts() {
        String sql = "SELECT * FROM eproduct";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(EProduct.class));
    }
}
