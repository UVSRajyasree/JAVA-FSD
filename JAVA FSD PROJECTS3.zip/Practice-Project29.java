package project;

public class LinearSearch {

	public static int linearSearch(int num[], int search) {
		for(int i=0;i<num.length;i++) {
			if(num[i]==search) {
				return i;
			}
		}
		return -1;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {8,9,10,7,3,5,4,1,6};
		int search = 9;
		int indexPosition = LinearSearch.linearSearch(num, search);
		if(indexPosition<0) {
			System.out.println("Element not present");
		}else {
			System.out.println("Element present at position "+indexPosition);
		}

		
	}

}
