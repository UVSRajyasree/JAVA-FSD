package project;

public class BubbleSorting {

	public static void bubbleSortAscending(int num[], int size) {
		for(int i=0;i<size-1;i++) {
			for(int j=0;j<size-1;j++) {
				if(num[j]>num[j+1]) {
					int temp = num[j];
					num[j]=num[j+1];
					num[j+1]=temp;
				}
			}
		}
	}
	
	public static void bubbleSortDescending(int num[], int size) {
		for(int i=0;i<size-1;i++) {
			for(int j=0;j<size-1;j++) {
				if(num[j]<num[j+1]) {
					int temp = num[j];
					num[j]=num[j+1];
					num[j+1]=temp;
				}
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {1,5,6,7,2,9,3,4,8,10};
		System.out.println("Before sort");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
		
		BubbleSorting.bubbleSortAscending(num, num.length);
		System.out.println();
		System.out.println("After sort in Ascending");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
		
		BubbleSorting.bubbleSortDescending(num, num.length);
		System.out.println();
		System.out.println("After sort in Descending");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
	}

}
