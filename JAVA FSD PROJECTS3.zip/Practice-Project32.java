package project;

public class SelectionSorting {

	public static void selectionSortAscending(int num[], int size) {
		for(int i=0;i<size-1;i++) {
			int min=i;
				for(int j=i+1;j<size;j++) {
					if(num[j]<num[min]) {
						min=j;
					}
				}	
		int temp = num[i];
		num[i]=num[min];
		num[min]=temp;
		}
	}
	public static void selectionSortDescending(int num[], int size) {
		for(int i=0;i<size-1;i++) {
			int max=i;
				for(int j=i+1;j<size;j++) {
					if(num[j]>num[max]) {
						max=j;
					}
				}	
		int temp = num[i];
		num[i]=num[max];
		num[max]=temp;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {9,2,3,4,6,1,7,8,10};
		System.out.println("Before sort");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
		SelectionSorting.selectionSortAscending(num, num.length);
		System.out.println();
		System.out.println("After sort in Ascending");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
		SelectionSorting.selectionSortDescending(num, num.length);
		System.out.println();
		System.out.println("After sort in Descending");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
	}

}
