package project;

public class InsertionSorting {

	public static void insertionSortAscending(int num[], int size) {
		for(int i=1;i<size;i++) {
			int key = num[i];
			int j=i-1;
			while(j>=0 && key < num[j]) {
				num[j+1]=num[j];
				j--;
			}
			num[j+1]=key;
		}
	}
	public static void insertionSortDescending(int num[], int size) {
		for(int i=1;i<size;i++) {
			int key = num[i];
			int j=i-1;
			while(j>=0 && key > num[j]) {
				num[j+1]=num[j];
				j--;
			}
			num[j+1]=key;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {3,6,7,8,10,2,5,9,4,1};
		System.out.println("Before sort");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
		
		InsertionSorting.insertionSortAscending(num, num.length);
		System.out.println();
		System.out.println("After sort in Ascending");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
		
		InsertionSorting.insertionSortDescending(num, num.length);
		System.out.println();
		System.out.println("After sort in Descending");
		for(int i=0;i<num.length;i++) {
			System.out.print(num[i]+" ");
		}
	}

}
