package project;

public class BinarySearch {

	public static void binarySearch(int num[], int start,int end, int search) {
		int mid = (start+end)/2;
		while(start<=end) {
			if(num[mid]<search) {
				start = mid+1;
			}else if(num[mid]==search) {
				System.out.println("Element is found "+mid);
				break;
			}else {
				end = mid-1;
			}
			mid = (start + end )/2;
		}
		if(start > end) {
			System.out.println("Element is not found");
		}
	}	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {1,2,6,9,7,8,3,4,5,10};
		int search = 2;
		int numlength = num.length;
		System.out.println();
		BinarySearch.binarySearch(num, 0, numlength, search);
	   

	}

}
