package project;

public class QuickSorting {
    //Ascending
	int quickSort(int arr[], int low, int high)
    {
        int pivot = arr[high];
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++)
        { 
            if (arr[j] <= pivot)
            {
                i++;

                // swap arr[i] and arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;

        return i+1;
    }



    void sort(int arr[], int low, int high)
    {
        if (low < high)
        {

            int pi = quickSort(arr, low, high);

            
            sort(arr, low, pi-1);
            sort(arr, pi+1, high);
        }
    }
    static void quickSortAscending(int arr[])
    {
        int n = arr.length;
        for (int i=0; i<n; ++i)
            System.out.print(arr[i]+" ");
        System.out.println();
    }
    //Descending
    int quickSort1(int arr[], int low, int high)
    {
        int pivot = arr[high];
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++)
        { 
            if (arr[j] >= pivot)
            {
                i++;

                // swap arr[i] and arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;

        return i+1;
    }



    void sort1(int arr[], int low, int high)
    {
        if (low < high)
        {

            int pi = quickSort1(arr, low, high);

            
            sort1(arr, low, pi-1);
            sort1(arr, pi+1, high);
        }
    }
    static void quickSortDescending(int arr[])
    {
        int n = arr.length;
        for (int i=0; i<n; ++i)
            System.out.print(arr[i]+" ");
        System.out.println();
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {5,6,10,2,7,8,9,1,3,4};
        int n = arr.length;
        System.out.println("Before sort");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i] + " ");
		}
		

        QuickSorting ob = new QuickSorting();
        ob.sort(arr, 0, n-1);

        System.out.println("\nAfter Sort in Ascending");
        quickSortAscending(arr);
        
        QuickSorting ob1 = new QuickSorting();
        ob1.sort1(arr, 0, n-1);

        System.out.println("After Sort in Descending");
        quickSortDescending(arr);

	}

}
