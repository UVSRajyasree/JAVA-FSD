package project;

public class TryCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		String s = "10";
		try {
			int b= a++;
			System.out.println("a value is : " + b );
			System.out.println("s value is : " + s.charAt(4));
			
		}catch(Exception e){
			System.out.println("Exception Found : " + e);
		}
       System.out.println(" Try Catch ");
	}

}
