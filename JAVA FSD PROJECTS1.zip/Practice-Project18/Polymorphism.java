package project;

class Multiply 
{
    public int multiply(int x, int y) 
    { 
        return (x * y); 
    } 
    public float multiply(float x, float y, float z) 
    { 
        return (x * y * z); 
    } 
    public double multiply(double x, double y) 
    { 
        return (x * y); 
    } 
}
public class Polymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Multiply s = new Multiply(); 
        System.out.println(s.multiply(10, 10)); 
        System.out.println(s.multiply(10.1f, 10.2f, 10.3f)); 
        System.out.println(s.multiply(10.5, 10.5)); 

	}

}
