package project;

class Encapsulate 
{ 
    private String Name; 
    private int Quantity; 
    private int Cost;
    public int getQuantity()  
    { 
      return Quantity; 
    } 
    public String getName()  
    { 
      return Name; 
    } 
    public int getCost()  
    { 
       return Cost; 
    } 
    public void setQuantity( int newQuantity) 
    { 
      Quantity = newQuantity; 
    } 
    public void setName(String newName) 
    { 
      Name = newName; 
    } 
    public void setCost( int newCost)  
    { 
      Cost = newCost; 
    } 
}

public class Encapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Encapsulate obj = new Encapsulate(); 
        obj.setName("Apple"); 
        obj.setQuantity(10); 
        obj.setCost(100); 
        System.out.println("My Favourite Fruit Name is : " + obj.getName()); 
        System.out.println("I buyed : " + obj.getQuantity()); 
        System.out.println("Cost is : " + obj.getCost());      

	}

}
