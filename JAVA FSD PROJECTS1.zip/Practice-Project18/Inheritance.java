package project;

class Subject  
{ 
    public int Marks; 
    public int Grade ; 
    public Subject(int Marks, int Grade) 
    { 
        this.Marks = Marks; 
        this.Grade = Grade; 
    } 
    public void totalMarks(int m) 
    { 
        m=100; 
    } 
    public void Grade(int g) 
    { 
        g=1;
    }  
    public String toString()  
    { 
        return("Total Marks " + Marks + "\n" + "Grade fot the Total Marks " + Grade); 
    }  
} 
class Mathematics extends Subject  
{ 
    public int Percentage; 
    public Mathematics(int Marks,int Grade,int PassMarks) 
    {  
        super(Marks, Grade); 
        Percentage = PassMarks; 
    }  
    public void Percentage(int newValue) 
    { 
        Percentage = newValue;
    } 
    @Override
    public String toString() 
    { 
        return (super.toString()+ 
                "\nPercentage is "+Percentage); 
    } 
}

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Mathematics m = new Mathematics(100, 1, 80); 
        System.out.println(m.toString());

	}

}
