package project;

abstract class City  
{ 
    String name; 
    abstract double population(); 
    public abstract String toString(); 
    public City(String name) 
    { 
        System.out.println("City constructor called"); 
        this.name = name; 
    } 
    public String getName() 
    { 
        return name; 
    } 
} 
class Aa extends City 
{ 
    double ra; 
    public Aa(String name,double ra) 
    { 
        super(name); 
        System.out.println("Aa constructor called"); 
        this.ra = ra; 
    }
    @Override
    double population() 
    { 
        return ra; 
    } 
    @Override
    public String toString() 
    { 
        return "Aa Name is " + super.name + " and population is : " + population(); 
    } 
} 
class Bb extends City
{ 
    double l; 
    public Bb(String name,double l) 
    { 
        super(name); 
        System.out.println("Bb constructor called"); 
        this.l = l;  
    } 
    @Override
    double population() 
    { 
        return l; 
    } 
    @Override
    public String toString() 
    { 
        return "Bb name is " + super.name +  
                           " and population is : " + population(); 
    } 
} 

public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        City s1 = new Aa("Hyderabad", 1523411); 
        City s2 = new Bb("Andhra Pradesh", 1511234);
        System.out.println(s1.toString()); 
        System.out.println(s2.toString()); 

	}

}
