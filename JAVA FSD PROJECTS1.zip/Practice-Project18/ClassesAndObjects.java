package project;

class Car
{  
    String name; 
    String model; 
    int numberofseats; 
    String color; 
    public Car(String name, String model, int numberofseats, String color) 
    { 
        this.name = name; 
        this.model = model; 
        this.numberofseats = numberofseats; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    } 
    public String getModel() 
    { 
        return model; 
    } 
    public int getNumberOfSeats() 
    { 
        return numberofseats; 
    } 
    public String getColor() 
    { 
        return color; 
    } 

@Override
public String toString() 
{ 
    return("Hi my favourite Car is "+ this.getName()+ ".\nIt's model is " + this.getModel()+", "+ "number of seats is " + this.getNumberOfSeats()+", "+  "color is " + this.getColor() + "."); 
} 
}

public class ClassesAndObjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Car c = new Car("Skoda Rapid","Sedan", 6, "NavyBlue"); 
        System.out.println(c.toString()); 
	}

}
