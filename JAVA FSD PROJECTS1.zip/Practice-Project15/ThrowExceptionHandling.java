package project;

public class ThrowExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String name="ABCD";
			
			try {
				
			if(name.length()<=4) {
				//throw new Exception();// generate generic pre defined exception only name 
				throw new Exception("Name must be More than Four Letters "); // name with message 
				//throw new ArithmeticException();// generating arithmetic exception with custom condition. 
				//throw new ArithmeticException("Age must be >=21");
				//throw new VoteException();	// custom exception empty constructor 
				// throw new VoteException("Age must be >21");custom exception parameter constructor 
			}else {
				System.out.println("Your Name has suffiencient Letters");
			}

			}catch(Exception e) {
				System.out.println("Exception " + e.toString());
			}
	}

}
