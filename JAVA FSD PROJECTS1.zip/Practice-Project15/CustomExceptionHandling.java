package project;

public class CustomExceptionHandling {
class MyException extends Exception{
	public MyException(){
	    super();	
	}
	public MyException(String s) 
    { 
        super();
		//super(s); 
    } 
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=1;
		try
        { 
			if(a==1) {
			System.out.println(a);
            throw new Exception("This is displayed"); 
        } else {
        	System.out.println("The Value of a is 1");
        }
        }
        
        catch (Exception e) 
        { 
            System.out.println("After Handling Exception"); 
            System.out.println(e.toString()); 
        } 

	}

}
