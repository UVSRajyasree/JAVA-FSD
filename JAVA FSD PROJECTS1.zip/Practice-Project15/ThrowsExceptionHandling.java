package project;

public class ThrowsExceptionHandling {
    void Array() throws Exception
    {
        int a[]= {10,20,30,40,50};
        int b=a[9];
        System.out.print("\n\tThe result is : " + b);
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThrowsExceptionHandling T = new ThrowsExceptionHandling();
        try
       {
           T.Array();
       }
       catch(Exception e)
       {
           System.out.print("\n\tException : " + e.getMessage() + e);
       }
       System.out.print("\n\tEnd of program.");

	}

}
