package project;


public class SleepAndWait {

	private static Object LOCK = new Object();
	public void Object1() {
		System.out.println("This new Object is displayed");
	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Thread.sleep(3000);
		System.out.println("This Thread " + Thread.currentThread().getName() + " is woken after sleeping for 3 seconds " );
		synchronized(LOCK)
		{
			LOCK.wait(1000);
			System.out.println("Object " + LOCK + " is woken after " + " waiting for 1 second ");
			
		}

	}

}
