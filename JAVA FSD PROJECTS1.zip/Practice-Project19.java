package project;

interface Primary 
{  
    default void show() 
    { 
        System.out.println("It Is Default Primary"); 
    } 
} 
interface Secondary 
{  
    default void show() 
    { 
        System.out.println("It is Default Secondary"); 
    } 
}  
class WorkStage implements Primary, Secondary 
{  
    public void show() 
    {  
        Primary.super.show(); 
        Secondary.super.show(); 
    } 
}
public class Diamond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       // It is Multiple Inheritance Implemented by Interface
		WorkStage ob = new WorkStage(); 
        ob.show(); 

	}

}
