package project;

//Thread
class S extends Thread {
	@Override
	public void run() {
		for(int i=0;i<=10;i++) {
			System.out.println("The Value of i is:  "+i);
		}
	}
	
}
class T extends Thread {
	@Override
	public void run() {
		for(int j=0;j<=10;j++) {
			System.out.println("The Value of j is:  "+j);
		}
	}
}
public class ExtendsThreadClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		S s = new S();
		T t = new T();	// s t is thread class	 
		s.start();      //ready to run
		t.start();     
	}

}
