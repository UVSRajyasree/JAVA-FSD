package project;

//Runnable Interface
class M implements Runnable{
	public static int a=0; 
	public M(){
		
	}
	@Override
	public void run() {
		while(M.a<=9) {
	        System.out.println("The Value of a is:  "+(++M.a));
		}
	}	
}
class N implements Runnable{
	public static int b=0;
	public N(){
		
	}
	@Override
	public void run() {
		while(N.b<=9) {
			System.out.println("The Value of b is: "+(N.b++));
		}
	}
}

public class ImplementsRunnableInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		M m = new M();
		N n = new N();
		Runnable r1 = new M();
		Runnable r2 = new N();			//sub class object and super interface reference 
		Thread t1 = new Thread(r1);		// t1 passing runnable interface 
		Thread t2 = new Thread(r2);		// t2 passing runnable interface
		t1.start();
		t2.start();
	}

}
