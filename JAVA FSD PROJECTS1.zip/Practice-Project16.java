package project;

class MyException extends Exception{
	   int a=10;
	   MyException(int b) {
		System.out.println("This is Exception occured in b");
	   }
	   public int c(){ 
		return (a) ;
	   }
	}

public class ExceptionHandlers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int b=10;
		try{
			System.out.println("Starting of try block " + b);
			// I'm throwing the custom exception using throw
			throw new MyException(b);
		}
		catch(MyException e){
			System.out.println("Catch Block") ;
			System.out.println(e) ;
		}

	}

}
