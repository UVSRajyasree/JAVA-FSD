package com;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class ScreenshotsAndBrowserProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		//System.out.println("Driver Loaded Successfully");
		//WebDriver driver = new ChromeDriver();	// created the reference of drive 
        WebDriver driver = new EdgeDriver();
	    // driver.get("https://www.google.com");  // we are loading google page 
        try {
            // Open Microsoft Edge and navigate to Google
        	driver.get("https://www.google.com");  // we are loading google page 

            // Perform a Google search
        	WebElement searchBox = driver.findElement(By.name("q"));
            searchBox.sendKeys("Hello, world!");
            searchBox.submit();

            // Convert WebDriver object to TakeScreenshot
            TakesScreenshot tsDriver = (TakesScreenshot) driver;

            // Call getScreenshotAs method to create image file
            File screenshotFile = tsDriver.getScreenshotAs(OutputType.FILE);

            // Define desired location to copy the file
            Path sourcePath = screenshotFile.toPath();
            Path destinationPath = Path.of("C:\\Users\\uppal\\Downloads\\Selenium Projects\\google_search_screenshot.png");

            // Copy file to desired location
            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);

            System.out.println("Screenshot captured and saved successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
	}

}
