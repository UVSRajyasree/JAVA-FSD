package com;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
		System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
	}

}
