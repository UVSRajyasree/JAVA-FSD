package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertionsTest {
	private WebDriver driver;
    private SoftAssert softAssert;

    @BeforeMethod
    public void setup() {
        // Set Chrome browser path
        System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        // Create Edge browser instance
        driver = new EdgeDriver();
        // Initialize SoftAssert
        softAssert = new SoftAssert();
    }

    @Test
    public void testGoogleTitle() {
        // Navigate to Google
        driver.get("https://www.google.com");
        // Get title
        String title = driver.getTitle();
        // Hard Assertion
        Assert.assertEquals(title, "Google", "Title is incorrect");
    }

    @Test
    public void testGoogleSearchButton() {
        // Navigate to Google
        driver.get("https://www.google.com");
        // Locate search button
        WebElement searchButton = driver.findElement(By.name("btnK"));
        // Soft Assertion
        softAssert.assertTrue(searchButton.isDisplayed(), "Search button is not displayed");
        softAssert.assertTrue(searchButton.isEnabled(), "Search button is not enabled");
        // Perform other actions if needed
    }
        @AfterMethod
        public void method(){
        	// Assert all soft assertions
            softAssert.assertAll();
            // Close the browser
            if (driver != null) {
                driver.quit();
            }
        }
}
