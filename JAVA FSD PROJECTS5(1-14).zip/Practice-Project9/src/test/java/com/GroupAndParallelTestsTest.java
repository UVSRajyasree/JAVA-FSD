package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class GroupAndParallelTestsTest {

	    private WebDriver chromeDriver;
	    private WebDriver edgeDriver;

	    @BeforeMethod
	    public void setup() {
	        // Set Chrome browser path
	        System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	        // Create Chrome browser instance
	        chromeDriver = new ChromeDriver();

	        // Set Edge browser path
	        System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	        // Create Edge browser options
	        EdgeOptions options = new EdgeOptions();
	        // Create Edge browser instance
	        edgeDriver = new EdgeDriver(options);
	    }

	    @Test(groups = "Chrome")
	    public void testGoogleSearchInChrome() {
	        // Navigate to Google using Chrome
	        chromeDriver.get("https://www.google.com");
	        Assert.assertTrue(chromeDriver.getTitle().contains("Selenium"));
	    }

	    @Test(groups = "Edge")
	    public void testGoogleSearchInEdge() {
	        // Navigate to Google using Edge
	        edgeDriver.get("https://www.google.com");
	        Assert.assertTrue(edgeDriver.getTitle().contains("Selenium"));
	    }

	    @AfterMethod
	    public void method() {
	    	// Close the browsers
	        if (chromeDriver != null) {
	            chromeDriver.quit();
	        }
	        if (edgeDriver != null) {
	            edgeDriver.quit();
	        }
	    }

}
