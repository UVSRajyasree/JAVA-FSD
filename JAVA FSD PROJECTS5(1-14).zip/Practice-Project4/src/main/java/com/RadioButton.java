package com;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class RadioButton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Locate the radio buttons
        List<WebElement> radioButtons = driver.findElements(By.name("gender"));

        // Example: select the second radio button
        radioButtons.get(1).click();

        // Verify if the radio button is displayed
        boolean isRadioButtonDisplayed = radioButtons.get(1).isDisplayed();
        System.out.println("Is radio button displayed? " + isRadioButtonDisplayed);

        // Verify if the radio button is enabled
        boolean isRadioButtonEnabled = radioButtons.get(1).isEnabled();
        System.out.println("Is radio button enabled? " + isRadioButtonEnabled);

        // Verify if the radio button is selected
        boolean isRadioButtonSelected = radioButtons.get(1).isSelected();
        System.out.println("Is radio button selected? " + isRadioButtonSelected);

        // Close the browser
        driver.quit();
	}

}
