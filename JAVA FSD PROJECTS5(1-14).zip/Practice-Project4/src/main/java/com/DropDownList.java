package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.Select;

public class DropDownList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Locate the dropdown element
        WebElement dropdown = driver.findElement(By.name("country"));

        // Check if the dropdown exists
        boolean isDropdownExists = dropdown.isDisplayed();
        System.out.println("Is dropdown exists? " + isDropdownExists);

        // Check if the dropdown is enabled
        boolean isDropdownEnabled = dropdown.isEnabled();
        System.out.println("Is dropdown enabled? " + isDropdownEnabled);

        // Create a Select object for interacting with the dropdown
        Select select = new Select(dropdown);

        // Select an item by index (example: selecting the third item)
        select.selectByIndex(2);

        // Get the count of items in the dropdown
        int itemCount = select.getOptions().size();
        System.out.println("Number of items in the dropdown: " + itemCount);

        // Close the browser
        driver.quit();
	}

}
