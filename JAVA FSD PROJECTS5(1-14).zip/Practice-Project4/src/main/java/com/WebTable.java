package com;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class WebTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Locate the web table
        WebElement table = driver.findElement(By.xpath("//table[@id='tableID']")); // Update XPath with the actual XPath of your table

        // Get the rows of the table
        List<WebElement> rows = table.findElements(By.tagName("tr"));

        // Get the number of rows
        int rowCount = rows.size();
        System.out.println("Number of rows in the table: " + rowCount);

        // Example: Iterate through each row and get the cell values
        for (WebElement row : rows) {
            List<WebElement> cells = row.findElements(By.tagName("td"));
            for (WebElement cell : cells) {
                String cellValue = cell.getText();
                System.out.print(cellValue + "\t");
            }
            System.out.println();
        }

        // Close the browser
        driver.quit();
	}

}
