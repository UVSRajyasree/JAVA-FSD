package com;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;

public class SwitchingBetweenTabsInSameBrowserWindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Perform operations in the first tab
        // For example, perform a search
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Selenium");
        searchBox.sendKeys(Keys.ENTER);

        // Open a new tab using Ctrl + t
        Actions action = new Actions(driver);
        action.keyDown(Keys.CONTROL).sendKeys("t").keyUp(Keys.CONTROL).build().perform();

        // Perform operations in the new tab
        // For example, navigate to another website
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.get("https://www.example.com");

        // Switch back to the first tab using Ctrl + Tab
        action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).keyUp(Keys.CONTROL).build().perform();

        // Switch back to the old tab by pressing Ctrl+Tab repeatedly until reaching the desired tab
        // For example, press Ctrl+Tab two more times to reach the first tab
        action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).keyUp(Keys.CONTROL).build().perform();
        action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).keyUp(Keys.CONTROL).build().perform();

        // Perform operations in the first tab
        // For example, click on a link
        WebElement link = driver.findElement(By.linkText("Link Text"));
        link.click();

        // Close the browser
        driver.quit();
	}

}
