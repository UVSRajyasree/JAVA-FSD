package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class CheckBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Locate the "I agree" checkbox
        WebElement checkbox = driver.findElement(By.name("agree"));

        // Check if the checkbox is displayed
        boolean isCheckboxDisplayed = checkbox.isDisplayed();
        System.out.println("Is checkbox displayed? " + isCheckboxDisplayed);

        // Check if the checkbox is enabled
        boolean isCheckboxEnabled = checkbox.isEnabled();
        System.out.println("Is checkbox enabled? " + isCheckboxEnabled);

        // Check if the checkbox is selected
        boolean isCheckboxSelected = checkbox.isSelected();
        System.out.println("Is checkbox selected? " + isCheckboxSelected);

        // Select the checkbox (if not already selected)
        if (!isCheckboxSelected) {
            checkbox.click();
            System.out.println("Checkbox selected.");
        }

        // Unselect the checkbox (if it was initially selected)
        if (isCheckboxSelected) {
            checkbox.click();
            System.out.println("Checkbox unselected.");
        }

        // Close the browser
        driver.quit();
	}

}
