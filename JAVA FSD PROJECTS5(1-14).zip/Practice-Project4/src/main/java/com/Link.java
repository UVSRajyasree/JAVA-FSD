package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class Link {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
        // Locate the link
        WebElement link = driver.findElement(By.linkText("About"));

        // Click the link
        link.click();

        // Check link existence
        boolean isLinkPresent = driver.findElements(By.linkText("About")).size() > 0;
        System.out.println("Is link present? " + isLinkPresent);

        // Check link enabled status
        boolean isLinkEnabled = link.isEnabled();
        System.out.println("Is link enabled? " + isLinkEnabled);

        // Return the link name
        String linkName = link.getText();
        System.out.println("Link name: " + linkName);
        
        
        // Close the browser
        driver.quit();
	}

}
