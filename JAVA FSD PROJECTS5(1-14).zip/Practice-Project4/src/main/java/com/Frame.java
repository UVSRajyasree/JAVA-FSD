package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class Frame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
        // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Navigate to Google
        driver.get("https://www.google.com");

        // Example: Switch to a frame by name or ID
        driver.switchTo().frame("iframe1");

        // Example: Switch to a frame by locating the frame element
        // WebElement frameElement = driver.findElement(By.id("frameID"));
        // driver.switchTo().frame(frameElement);

        // Perform operations within the frame
        // For example, interact with elements inside the frame
        // driver.findElement(By.tagName("input")).sendKeys("Text");

        // Switch back to the top window
        driver.switchTo().defaultContent();

        // Close the browser
        driver.quit();
	}

}
