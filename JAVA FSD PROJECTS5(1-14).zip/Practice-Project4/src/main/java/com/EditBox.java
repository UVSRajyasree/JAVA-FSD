package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class EditBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
        //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
        driver.get("https://www.google.com");  // we are loading google page 
     // Create Edge browser options
        EdgeOptions options = new EdgeOptions();
        
     // Locate the search edit box
        WebElement searchBox = driver.findElement(By.name("q"));

        // Enter a value
        searchBox.sendKeys("Selenium testing");

        // Clear the value
        searchBox.clear();

        // Check enabled status
        boolean isEnabled = searchBox.isEnabled();
        System.out.println("Is edit box enabled? " + isEnabled);

        // Check edit box existence
        boolean isPresent = driver.findElements(By.name("q")).size() > 0;
        System.out.println("Is edit box present? " + isPresent);

        // Get the value
        String value = searchBox.getAttribute("value");
        System.out.println("Value of edit box: " + value);
        
        // Close the browser
        driver.quit();
	}

}
