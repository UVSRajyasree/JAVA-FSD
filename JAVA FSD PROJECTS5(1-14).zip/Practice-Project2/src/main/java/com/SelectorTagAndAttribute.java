package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class SelectorTagAndAttribute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
	    //System.out.println("Driver Loaded Successfully");
	    //WebDriver driver = new ChromeDriver();	// created the reference of drive 
	    WebDriver driver = new EdgeDriver();
	    driver.get("https://www.google.com");  // we are loading google page 
	    WebElement searchBox = driver.findElement(By.cssSelector("input[name='q']"));
        searchBox.sendKeys("Selenium");
        searchBox.submit();
	}

}
