package com.testannotations;

public class TestAnnotations {

}
