package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class FileUploads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		//System.out.println("Driver Loaded Successfully");
		//WebDriver driver = new ChromeDriver();	// created the reference of drive 
        WebDriver driver = new EdgeDriver();
	    // driver.get("https://www.google.com");  // we are loading google page 
        // Locate the file input field 
        WebElement fileInput = driver.findElement(By.name("q"));

        // Specify the file path using sendKeys()
        fileInput.sendKeys("C:\\\\Users\\\\uppal\\\\Downloads\\\\Selenium Projects");


        // Close the browser
        driver.quit();
	}

}
