package com;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class FileUploadsInAutoIT {

	public static void main(String[] args) throws IOException, InterruptedException{
		// TODO Auto-generated method stub
		WebDriver driver = new EdgeDriver();
		 // Execute the AutoIT script to handle file upload dialog
        Runtime.getRuntime().exec("C:\\Users\\uppal\\Downloads\\Selenium Projects.exe");

        // Add a delay to ensure the file upload completes
        Thread.sleep(2000);

        // Close the browser
        driver.quit();
    
	}

}
