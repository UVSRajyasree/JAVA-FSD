package com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class ExternalElememts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\uppal\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe");
	    System.setProperty("webdriver.edge.driver", "C:\\Users\\uppal\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		//System.out.println("Driver Loaded Successfully");
		//WebDriver driver = new ChromeDriver();	// created the reference of drive 
        WebDriver driver = new EdgeDriver();
	    driver.get("https://www.google.com");  // we are loading google page 
	    //To click on OK button in pop up
	    driver.switchTo().alert().accept();
	    //To click on Cancel button in pop up 
	    driver.switchTo().alert().dismiss();
	    //To Capture the alert message
	    driver.switchTo().alert().getText();
	    //To enter the information
	    driver.switchTo().alert().sendKeys("text");
	    //To exit from the popup
	    ((WebDriver)driver.switchTo().alert()).close();
	    //Opening new tab
	    driver.findElement(By.id("xyz")).sendKeys(Keys.CONTROL + "t");
	    //Opening new Window
	    WebElement newWindowButton = driver.findElement(By.linkText("Terms of Service"));
	    newWindowButton.click();
	}

}
