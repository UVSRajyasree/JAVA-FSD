package com.example;

public class UserBean {

	private String userName;

    public UserBean() {
        userName = "Ram";
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
