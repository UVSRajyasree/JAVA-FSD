package com.SpringIntializerProjectData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntializerProjectDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
