package com.SpringIntializerProjectData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIntializerProjectDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringIntializerProjectDataApplication.class, args);
	}

}
