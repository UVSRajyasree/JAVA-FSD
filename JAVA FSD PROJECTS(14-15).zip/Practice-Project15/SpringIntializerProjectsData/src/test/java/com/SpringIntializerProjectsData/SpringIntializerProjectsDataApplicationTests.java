package com.SpringIntializerProjectsData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntializerProjectsDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
