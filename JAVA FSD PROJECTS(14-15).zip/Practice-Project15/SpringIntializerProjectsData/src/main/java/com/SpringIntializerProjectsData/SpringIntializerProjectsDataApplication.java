package com.SpringIntializerProjectsData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIntializerProjectsDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringIntializerProjectsDataApplication.class, args);
	}

}
