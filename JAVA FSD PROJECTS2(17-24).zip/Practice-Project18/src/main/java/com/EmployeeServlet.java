package com;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.example.model.Employee; 
/**
 * Servlet implementation class EmployeeServlet
 */
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   // public EmployeeServlet() {
   //     super();
        // TODO Auto-generated constructor stub
   // }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Initialize Hibernate
            Configuration configuration = new Configuration().configure();
            SessionFactory sessionFactory = configuration.buildSessionFactory();

            // Open a session
            Session session = sessionFactory.openSession();

            // Begin a transaction
            Transaction transaction = session.beginTransaction();

            // Retrieve employees from the database
            List<Employee> employees = session.createQuery("FROM Employee", Employee.class).list();

            // Display employees
            out.println("<h2>Employee List</h2>");
            for (Employee employee : employees) {
                out.println("<p>ID: " + employee.getId() + "<br/>");
                out.println("Name: " + employee.getFirstName() + " " + employee.getLastName() + "<br/>");
                out.println("Salary: " + employee.getSalary() + "</p>");
            }

            // Commit the transaction
            transaction.commit();

            // Close the session and session factory
            session.close();
            sessionFactory.close();

        } catch (Exception e) {
            e.printStackTrace();
        
    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
